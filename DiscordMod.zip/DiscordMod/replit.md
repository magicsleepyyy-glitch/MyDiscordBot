# Discord Moderation Bot

## Overview
A comprehensive Discord moderation bot built with Discord.js that provides automated content filtering, user management, and moderation commands.

## Features
- **Auto-Moderation**: Spam detection, word filtering, excessive mentions blocking
- **Moderation Commands**: Kick, ban, mute, warn, and bulk message deletion
- **Logging**: All moderation actions logged to a dedicated channel
- **Configurable**: Easy to customize blocked words, spam limits, and settings

## Recent Changes
- Added role management commands: `p!addrole` and `p!removerole` (November 18, 2025)
- Added `p!unban` command to unban users (November 18, 2025)
- Changed prefix to `p!` (November 18, 2025)
- Added `p!clearwarnings` command to remove warnings
- Fixed multi-guild support with guild-scoped data
- Fixed per-command permission checks
- Initial setup (November 18, 2025)
- Implemented core moderation features
- Added auto-moderation system
- Created configurable word filter

## Project Architecture
- `index.js`: Main bot file with event handlers
- `config.json`: Bot configuration (prefix, blocked words, limits, owner-only roles)
- Discord.js v14 for Discord API interaction
- Event-driven architecture with command handling

## Owner-Only Roles
Certain sensitive roles can only be assigned/removed by the server owner. Edit the `ownerOnlyRoles` list in `config.json` to specify which roles require owner permissions. By default:
- Admin
- Administrator
- Owner
- Moderator

This prevents moderators from giving themselves admin/owner roles.

## Setup Instructions
1. The Discord integration handles bot token automatically
2. Customize `config.json` to add your own blocked words and settings
3. Invite the bot to your server with Administrator permissions
4. Create a text channel named "mod-logs" for moderation logging
5. The bot will auto-create a "Muted" role if it doesn't exist

## Commands
- `p!kick @user [reason]` - Kick a user from the server
- `p!ban @user [reason]` - Ban a user from the server
- `p!unban <userID>` - Unban a user by their ID
- `p!mute @user [reason]` - Mute a user (prevent them from sending messages)
- `p!unmute @user` - Unmute a user
- `p!warn @user [reason]` - Warn a user
- `p!warnings @user` - Check warnings for a user
- `p!clearwarnings @user` - Remove all warnings from a user
- `p!addrole @user <role name>` - Add a role to a user
- `p!removerole @user <role name>` - Remove a role from a user
- `p!clear <amount>` - Delete bulk messages (1-100)
- `p!help` - Display all available commands

## Auto-Moderation Features
- Blocks messages containing configured blocked words
- Prevents spam (too many messages in short time)
- Blocks excessive mentions (more than 5 mentions)
- All auto-mod actions are logged

## User Preferences
None specified yet.
